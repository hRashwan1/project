#ifndef WELCOME_H
#define WELCOME_H

#include <QDialog>

namespace Ui {
class welcome;
}

class welcome : public QDialog
{
    Q_OBJECT

public:
    explicit welcome(QWidget *parent = nullptr,QString username="",int age=0);
    ~welcome();
    //void setname(QString username);
    //void setage(QString age);

private slots:
    void on_logout_clicked();

private:
    Ui::welcome *ui;
};

#endif // WELCOME_H
