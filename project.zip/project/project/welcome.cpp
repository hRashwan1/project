#include "welcome.h"
#include "ui_welcome.h"
#include "users.h"
#include "mainwindow.h"
#include<QPixmap>
welcome::welcome(QWidget *parent, QString username, int age)
    : QDialog(parent)
    , ui(new Ui::welcome)
{
    ui->setupUi(this);
        //username=MainWindow::info;
    QString ageSt = QString::number(age);
    ui->hello->setText("Hello " + username + ageSt);
    QPixmap pix(":/new/prefix1/istockphoto-1494642262-612x612.jpg");
    ui->label->setPixmap(pix.scaled(400,400));
    //QString username();
    //int age();
}

welcome::~welcome()
{
    delete ui;
}
//void welcome::setname(QString lblusername){
    //int age=1;
    //QString x = QString::number(age);
   // ui->hello->setText(lblusername);



//}

void welcome::on_logout_clicked()
{
    hide();
    MainWindow* mainw= new MainWindow(this);
    mainw->show();
}


