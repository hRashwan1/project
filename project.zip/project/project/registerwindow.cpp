#include "registerwindow.h"
#include "ui_registerwindow.h"
#include "users.h"
#include "welcome.h"


registerwindow::registerwindow(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::registerwindow)
{
    ui->setupUi(this);
    ui->label_7->setVisible(false);
    ui->label_8->setVisible(false);
    ui->label_10->setVisible(false);
    ui->label_9->setVisible(false);


    //int x=year.toInt();





}

registerwindow::~registerwindow()
{
    delete ui;
}
//QString username2=ui->LineEdit->text();
//QString pass2=ui->LineEdit_1->text();
//QString retypepass= ui->LineEdit_2->text();

void registerwindow::on_pushButton_clicked()
{
    ui->label_7->setVisible(false);
    ui->label_8->setVisible(false);
    ui->label_10->setVisible(false);
    ui->label_9->setVisible(false);

    QString username2=ui->lineEdit->text();
    QString pass2=ui->lineEdit_2->text();
    QString retypepass= ui->lineEdit_3->text();
    QString Day=ui->lineEdit_4->text();

    QString year=  ui->lineEdit_5->text();
    int x=year.toInt();

    QString month=ui->comboBox->currentText();
    bool male= ui->male->isChecked();
    bool female= ui->female->isChecked();
    bool user= ui->user->isChecked();
    bool admin= ui->admin->isChecked();

    bool action= ui->action->isChecked();
    bool comedy= ui->comedy->isChecked();
    bool romance= ui->romance->isChecked();
    bool drama= ui->drama->isChecked();
    bool horror= ui->horror->isChecked();
    bool other= ui->other->isChecked();

    bool found1=true;
    bool found2=true;
    bool found3=true;
    bool found4=true;


    for(int i=0;i<usersCount;i++){

        if(username2==usernames[i]){
            ui->label_7->setVisible(true);
            found1=false;
        }}

        ////

        if(pass2!=retypepass){
            ui->label_8->setVisible(true);
            found2=false;
        }


        if((2024-x)<12)
        {
        ui->label_9->setVisible(true);
            found3=false;
         }
        if((username2=="")or(pass2=="")or(retypepass=="")or(Day=="")or(year=="")or((male==false)&&(female==false))or((user==false)&&(admin==false))or
         ((action==false)&&(comedy==false)&&(romance==false)&&(drama==false)&&(horror==false)&&(other==false)))
            {
            ui->label_10->setVisible(true);
            found4=false;
        }
        if(((found1)&&(found2)&&(found3)&&(found4))==true){
        usernames[usersCount]=username2;
        passwords[usersCount]=pass2;
        ages[usersCount]=2024-x;

        hide();
        welcome* welcomew= new welcome(this,username2,(2024-x));
        welcomew->setVisible(true);
        welcomew->show();
        usersCount++;}
    }


    /*int i = 0;
    while (i < usernames[100].size()) {
        if (username2 == usernames[i]) {
            ui->label_7->setVisible(true);
        }
        i++;
    }

    // Other checks
    if (pass2 != retypepass) {
        ui->label_8->setVisible(true);
    }

    if ((2024 - x) < 12) {
        ui->label_9->setVisible(true);
    }

    if (username2.isEmpty() || pass2.isEmpty() || retypepass.isEmpty() || Day.isEmpty() || year.isEmpty() || (!male && !female) || (!user && !admin) || (!action && !comedy && !romance && !drama && !horror && !other)) {
        ui->label_10->setVisible(true);
    }
    usernames[usersCount]=username2;
    passwords[usersCount]=pass2;
    ages[usersCount]=x;
    usersCount++;*/





